setwd("C:\\Users\\it24100430\\Desktop\\IT24100430")
data<-read.table("DATA 4.txt",header= TRUE,sep = " ")
fix(data)
attach(data)
boxplot(x1,main="Box plot for Team Attendence",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(x2,main="Box plot for Team Salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(x3,main="Box plot for Years",outline=TRUE,outpch=8,horizontal=TRUE)

hist(x1,ylab="Frequency",xlab="Team Attendence",main="Historgram for Team Attendence")
hist(x2,ylab="Frequency",xlab="Team Salary",main="Historgram for Team Salary")
hist(x3,ylab="Frequency",xlab=" Years",main="Historgram for  Years")

stem(x1)
stem(x2)
stem(x3)

mean(x1)
mean(x2)
mean(x3)

median(x1)
median(x2)
median(x3)

sd(x1)
sd(x2)
sd(x3)

summary(x1)
summary(x2)
summary(x3)

quantile(x1)

quantile(x1)[2]

quantile(x1)[4]

IQR(x1)
IQR(x2)
IQR(x3)

get.mode<-function(y){
  counts,-table(x3)
  names(counts[counts == max(counts)])
}
get.mode(x3)
table(x3)
max(counts)
counts == max(counts)
counts[counts == max(counts)]
names(counts[counts == max(counts)])

get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 + 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers = ", paste(sort(z[z<lb | z>ub]), collapse = ",")))
}

get.outliers(x1)
get.outliers(x2)
get.outliers(x3)

get.outliers<-function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  
  print(paste("Outliers:", paste(sort(z[z<lb | z>ub]), collapse = ",")))
}
